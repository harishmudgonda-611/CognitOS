"""
Memory Engine
"""