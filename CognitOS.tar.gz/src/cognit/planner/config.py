class PlannerConfig:

    ENABLED = True
