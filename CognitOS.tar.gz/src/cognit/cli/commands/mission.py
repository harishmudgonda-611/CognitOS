from cognit.mission.runner import MissionRunner


def mission():
    runner = MissionRunner()

    mission, plan, workflow = runner.run(
        title="Build Todo App",
        description="Create a simple Todo application",
        task_titles=[
            "Create Project",
            "Create Pages",
            "Run Tests"
        ]
    )

    print("Mission :", mission.title)
    print("Status  :", mission.status)
    print("Tasks   :", len(plan.tasks))
    print("Workflow:", workflow.name)
