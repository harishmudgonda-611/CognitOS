from cognit.workflow.service import WorkflowService


class PlanWorkflowAdapter:
    def __init__(self):
        self.workflow = WorkflowService()

    def convert(self, plan):
        tasks = []

        for task in plan.tasks:
            title = task.title.lower()

            if "project" in title:
                capability = "builder.react"
            elif "page" in title:
                capability = "builder.ui"
            elif "test" in title:
                capability = "verifier.test"
            else:
                capability = "general"

            tasks.append({
                "title": task.title,
                "capability": capability
            })

        return self.workflow.create(plan.mission, tasks)
